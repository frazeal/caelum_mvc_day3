﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogWeb.Models.Dominio;
using BlogWeb.Models.Infra;
using NHibernate;

namespace BlogWeb.Models.DAO {
    public class PostDao {

        public IList<Post> Listar() {
            using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                string hqlCommand = "select p from Post p";
                IQuery q = sessao.CreateQuery(hqlCommand);
                return q.List<Post>();
            }
        }

        public void Adicionar(Post post) {
            using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                using (ITransaction tx = sessao.BeginTransaction()) {
                    sessao.Save(post);
                    tx.Commit();
                }
            }
        }

        public Post BuscarPorId(int id) {
            using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                return sessao.Get<Post>(id); 
            } 
        }

        public void Remover(Post post) {
            using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                ITransaction tx = sessao.BeginTransaction();
                sessao.Delete(post); 
                tx.Commit(); 
            } 
        }

        public void Atualizar(Post post) {
            using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                ITransaction tx = sessao.BeginTransaction();
                sessao.Merge(post); 
                tx.Commit(); 
            } 
        } 

    }
}