﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
//using BlogWeb.Models.Dominio;

namespace BlogWeb.Models.Dominio {

    public class Post {

        public virtual int Id { get; set; }
        
        [Required(ErrorMessage = "Por favor preencha o campo")]
        [StringLength(20, ErrorMessage = "Digite no	máximo 20 caracteres")]
        public virtual string Titulo { get; set; }

        public virtual string Conteudo { get; set; }
        [DisplayFormat(DataFormatString="{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public virtual DateTime? DataPublicacao { get; set; }
        public virtual bool Publicado { get; set; }

    }
}